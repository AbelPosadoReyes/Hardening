author: Abel Posado Reyes
summary: Asegurar la BIOS correctamente desde un simulador web
id: equipo-simulado-bios
categories: codelab,markdown
environments: Web
status: Published
feedback link: Un enlace en el que los usuarios puedan darte feedback (quizás creando un issue en un repositorio de git)
analytics account: ID de Google Analytics
# Equipo Simulado.

##Paso 1
Duration: 0:02:00

Debemos acceder a la web y elegir nuestra propia BIOS. En este caso va a ser IdeaCentre AIO V310z 10QG, 10GH. 

![Releases de claat](img/2.1.png)

##Paso 2
Duration: 0:02:00

Una vez estemos dentro de la BIOS, vamos a entrar en el apartado Security y vamos a retocar la contraseña de Administrador.

![Releases de claat](img/2.2.png)

##Paso 3
Duration: 0:02:00

Una vez hayamos puesto contraseña al administrador vamos a realizar el siguiente paso que es el cambiar la contraseña del Power-On (cada vez que arranquemos el equipo tendremos que poner una contraseña diferente a la de antes, ya que la de antes es para poder configurar la BIOS y esta para inciar la compuradora)

![Releases de claat](img/2.3.png)
