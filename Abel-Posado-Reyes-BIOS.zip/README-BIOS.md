#README.md
Esta es la carpeta creada:
		https://github.com/AbelPosadoReyes/Hardening/tree/main/Bios
Equipo real:
		https://github.com/AbelPosadoReyes/Hardening/tree/main/Bios/equipo-real-bios
Equipo simulado:
		https://github.com/AbelPosadoReyes/Hardening/tree/main/Bios/equipo-simulado-bios